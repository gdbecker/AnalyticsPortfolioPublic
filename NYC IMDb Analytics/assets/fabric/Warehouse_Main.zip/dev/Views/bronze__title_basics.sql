-- Auto Generated (Do not modify) 7D9CB8655803C8D034DF8EE073D7BD0C570593F1CC1548F769CD1B7752719E70
create view "dev"."bronze__title_basics" as select
  tconst,
  titleType as title_type,
  primaryTitle as primary_title,
  originalTitle as original_title,
  case
    when isAdult = '0' then 'false'
    when isAdult = '1' then 'true'
    else null 
  end as is_adult,
  startYear as start_year,
  endYear as end_year,
  runtimeMinutes as runtime_minutes,
  genres
from "Warehouse_Main"."dbo"."raw__title_basics";