-- Auto Generated (Do not modify) 8615B21D311B57B36CD62A746042411289657E6FF5C55DB1F03BC1FE6BDAA3DC
create view "dev"."bronze__name_basics" as select
  nconst,
  primaryName as primary_name,
  birthYear as birth_year,
  deathYear as death_year,
  primaryProfession as primary_profession,
  knownForTitles as known_for_titles
from "Warehouse_Main"."dbo"."raw__name_basics";