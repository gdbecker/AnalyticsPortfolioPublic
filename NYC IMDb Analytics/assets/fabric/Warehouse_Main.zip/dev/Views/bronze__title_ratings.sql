-- Auto Generated (Do not modify) 32542CA6F99E0D9526DC4B1742B4B8399BC96A823AF123AA5B8C93D9CA0855A8
create view "dev"."bronze__title_ratings" as select
  tconst,
  averageRating as average_rating,
  numVotes as num_votes
from "Warehouse_Main"."dbo"."raw__title_ratings";