-- Auto Generated (Do not modify) 3A49D7A1FE65811C833871E1D39CBE5C672D63671885F61526F4213F79B5AEBD
create view "dev"."bronze__filming_locations" as select
  "1" as row_index,
  "Film" as film,
  "Year" as year,
  "URL Encoded name" as url_encoded_name,
  "Image File Name" as image_file_name,
  "Agency Credit" as agency_credit,
  "Artist Credit" as artist_credit,
  "Director/Filmmaker Name" as director_or_filmmaker_name,
  "Director/Filmmaker IMDB Link" as director_or_filmmaker_imdb_link,
  "Location Display Text" as location_display_text,
  "LATITUDE" as latitude,
  "LONGITUDE" as longitude,
  "Borough" as borough,
  "Neighborhood" as neighborhood,
  "Scene Type" as scene_type,
  "Media" as media,
  "IMDB LINK" as imdb_link,
  "Client or book location indicator" as client_or_book_location_indicator,
  "Notes" as notes,
  case
    when "Book Image" = 'N' then 'false'
    when "Book Image" = 'Y' then 'true'
    else null 
  end as book_image,
  "Book Page" as book_page,
  case
    when "Display?" = 'N' then 'false'
    when "Display?" = 'Y' then 'true'
    when "Display?" = 'N/A' then null
    else null 
  end as display,
  case
    when "IMAGE OF LOCATION" = 'N' then 'false'
    when "IMAGE OF LOCATION" = 'Y' then 'true'
    else null 
  end as image_of_location
from "Warehouse_Main"."dbo"."raw__filming_locations";