CREATE TABLE [dev].[silver__title_basics] (

	[imdb_id] varchar(8000) NULL, 
	[title_type] varchar(8000) NULL, 
	[primary_title] varchar(8000) NULL, 
	[original_title] varchar(8000) NULL, 
	[is_adult] varchar(5) NULL, 
	[start_year] int NULL, 
	[end_year] int NULL, 
	[runtime_minutes] decimal(9,2) NULL, 
	[genres] varchar(8000) NULL
);