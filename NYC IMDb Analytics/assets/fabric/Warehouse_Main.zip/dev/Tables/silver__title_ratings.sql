CREATE TABLE [dev].[silver__title_ratings] (

	[imdb_id] varchar(8000) NULL, 
	[average_rating] decimal(9,6) NULL, 
	[num_votes] numeric(18,0) NULL
);