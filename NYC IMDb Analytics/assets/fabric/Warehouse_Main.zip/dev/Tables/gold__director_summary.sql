CREATE TABLE [dev].[gold__director_summary] (

	[director_or_filmmaker_imdb_id] varchar(8000) NULL, 
	[director_name] varchar(8000) NULL, 
	[birth_year] numeric(18,0) NULL, 
	[death_year] numeric(18,0) NULL, 
	[primary_profession] varchar(8000) NULL, 
	[total_films_directed] int NULL, 
	[genres_directed] varchar(8000) NULL, 
	[avg_film_rating] decimal(38,6) NULL, 
	[total_votes] numeric(38,0) NULL
);