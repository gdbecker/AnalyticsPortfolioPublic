CREATE TABLE [dev].[gold__film_catalog] (

	[imdb_id] varchar(8000) NULL, 
	[primary_title] varchar(8000) NULL, 
	[original_title] varchar(8000) NULL, 
	[title_type] varchar(8000) NULL, 
	[start_year] int NULL, 
	[end_year] int NULL, 
	[runtime_minutes] decimal(9,2) NULL, 
	[genre] varchar(8000) NULL, 
	[average_rating] decimal(9,6) NULL, 
	[num_votes] numeric(18,0) NULL, 
	[borough] varchar(8000) NULL, 
	[neighborhood] varchar(8000) NULL, 
	[location_display_text] varchar(8000) NULL
);