CREATE TABLE [dev].[silver__name_basics] (

	[director_or_filmmaker_imdb_id] varchar(8000) NULL, 
	[primary_name] varchar(8000) NULL, 
	[birth_year] numeric(18,0) NULL, 
	[death_year] numeric(18,0) NULL, 
	[primary_profession] varchar(8000) NULL, 
	[known_for_titles] varchar(8000) NULL
);