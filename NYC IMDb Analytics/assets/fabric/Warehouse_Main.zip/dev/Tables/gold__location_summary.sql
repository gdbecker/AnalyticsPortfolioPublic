CREATE TABLE [dev].[gold__location_summary] (

	[borough] varchar(8000) NULL, 
	[neighborhood] varchar(8000) NULL, 
	[latitude] decimal(9,6) NULL, 
	[longitude] decimal(9,6) NULL, 
	[num_films] int NULL, 
	[total_scenes] int NULL, 
	[genre] varchar(8000) NULL, 
	[avg_rating] decimal(38,6) NULL, 
	[avg_runtime_minutes] decimal(38,6) NULL
);