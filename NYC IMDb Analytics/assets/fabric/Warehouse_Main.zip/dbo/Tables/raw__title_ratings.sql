CREATE TABLE [dbo].[raw__title_ratings] (

	[tconst] varchar(8000) NULL, 
	[averageRating] float NULL, 
	[numVotes] bigint NULL
);