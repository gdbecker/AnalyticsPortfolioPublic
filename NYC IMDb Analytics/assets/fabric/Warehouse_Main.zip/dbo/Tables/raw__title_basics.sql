CREATE TABLE [dbo].[raw__title_basics] (

	[tconst] varchar(8000) NULL, 
	[titleType] varchar(8000) NULL, 
	[primaryTitle] varchar(8000) NULL, 
	[originalTitle] varchar(8000) NULL, 
	[isAdult] varchar(8000) NULL, 
	[startYear] varchar(8000) NULL, 
	[endYear] varchar(8000) NULL, 
	[runtimeMinutes] varchar(8000) NULL, 
	[genres] varchar(8000) NULL
);