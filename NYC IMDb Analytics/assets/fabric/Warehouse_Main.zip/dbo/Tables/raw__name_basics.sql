CREATE TABLE [dbo].[raw__name_basics] (

	[nconst] varchar(8000) NULL, 
	[primaryName] varchar(8000) NULL, 
	[birthYear] varchar(8000) NULL, 
	[deathYear] varchar(8000) NULL, 
	[primaryProfession] varchar(8000) NULL, 
	[knownForTitles] varchar(8000) NULL
);